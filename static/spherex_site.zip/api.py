"""
SPHEREx Sky Motion Viewer — backend API (FastAPI).

Запуск:
    pip install -r requirements.txt
    uvicorn api:app --reload --port 8000
Документация (Swagger) появится на http://localhost:8000/docs

Поток данных:
    сайт -> /api/search  (TAP IRSA: какие кадры есть в точке, эпохи)
         -> /api/frames  (скачать кутауты, перепроецировать на общую сетку, общая шкала яркости)
         -> /api/frame/{id}.png, /api/coadd.png, /api/diff.png  (картинки для плеера)
         -> /api/spectrum (фотометрия во всех кадрах)
         -> /api/gaia     (звёзды Gaia, сдвинутые на дату снимка)
Ничего не хранится навсегда: всё берётся из IRSA / Gaia Archive и кэшируется на диске.
"""

import hashlib
import io
import json
import math
import os
import shutil
import time
import warnings
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from pathlib import Path

import numpy as np
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import Response

import astropy.units as u
from astropy.coordinates import SkyCoord
from astropy.io import fits
from astropy.time import Time
from astropy.utils.data import conf as data_conf, download_file
from astropy.visualization import AsinhStretch, ImageNormalize
from astropy.wcs import WCS, FITSFixedWarning

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt                                  # noqa: E402
from reproject import reproject_interp                           # noqa: E402

warnings.filterwarnings("ignore", category=FITSFixedWarning)
warnings.filterwarnings("ignore", module="astropy")
data_conf.remote_timeout = 120

# ------------------------------------------------------------------ config --
CACHE = Path(os.environ.get("CACHE_DIR", "cache"))
GAIA_TABLE = os.environ.get("GAIA_TABLE", "gaiadr3.gaia_source")   # после 2.12.2026 -> DR4
SEARCH_TTL_S = int(os.environ.get("SEARCH_TTL_S", 12 * 3600))      # релизы IRSA еженедельные
IRSA_BASE = "https://irsa.ipac.caltech.edu/"
PIX_DEG = 6.15 / 3600            # пиксель SPHEREx ~6.15"
EPOCH_GAP_DAYS = 30              # разрыв > 30 дней = новая эпоха
MAX_FOV, MAX_FRAMES = 0.5, 250
WORKERS = int(os.environ.get("WORKERS", 12))      # параллельных загрузок из IRSA
GAIA_TTL_S = 30 * 24 * 3600                          # каталог Gaia не меняется
# Какие биты FLAGS считать плохими (0 = ничего не маскировать, только считать).
# Многие биты SPHEREx информационные (например, «в пикселе есть источник»),
# поэтому маскировать «всё ненулевое» нельзя — выбрасывались почти все пиксели.
BAD_BITS = int(os.environ.get("SPHEREX_BAD_BITS", "0"), 0)
CACHE_VER = "v2"                 # смена версии = старый кэш кадров игнорируется
for sub in ("search", "fits", "npy", "png", "gaia"):
    (CACHE / sub).mkdir(parents=True, exist_ok=True)

app = FastAPI(title="SPHEREx Sky Motion Viewer API", version="0.1")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET"],
                   allow_headers=["*"])   # открыто: инструмент можно встраивать на другие сайты
app.add_middleware(GZipMiddleware, minimum_size=1000)   # JSON со списками кадров сжимается в 5-10 раз


# ----------------------------------------------------------------- helpers --
def _key(*parts) -> str:
    return hashlib.sha1("|".join(map(str, parts)).encode()).hexdigest()[:20]


def _check(ra: float, dec: float, fov: float = 0.1):
    if not (0 <= ra < 360 and -90 <= dec <= 90):
        raise HTTPException(400, "ra должен быть 0..360, dec -90..90 (градусы)")
    if not (0.01 <= fov <= MAX_FOV):
        raise HTTPException(400, f"fov должен быть 0.01..{MAX_FOV} градуса")


def _retry(fn, *args, tries=3):
    for i in range(1, tries + 1):
        try:
            return fn(*args)
        except Exception:                                         # noqa: BLE001
            if i == tries:
                raise
            time.sleep(2 * i)


# ------------------------------------------------------------------ search --
def search_frames(ra: float, dec: float) -> list[dict]:
    """Все кадры SPHEREx, покрывающие точку. Кэш на SEARCH_TTL_S."""
    path = CACHE / "search" / f"{_key(round(ra, 4), round(dec, 4))}.json"
    if path.exists() and time.time() - path.stat().st_mtime < SEARCH_TTL_S:
        return json.loads(path.read_text())

    from astroquery.ipac.irsa import Irsa
    adql = f"""
        SELECT a.uri, p.time_bounds_lower, p.energy_bandpassname
        FROM spherex.artifact AS a
        JOIN spherex.plane AS p ON a.planeid = p.planeid
        WHERE 1 = CONTAINS(POINT('ICRS', {ra}, {dec}), p.poly)
        ORDER BY p.time_bounds_lower
    """
    tbl = _retry(lambda: Irsa.query_tap(adql).to_table())

    frames, seen = [], set()
    for row in tbl:
        uri = str(row["uri"]).strip()
        url = uri if uri.lower().startswith("http") else IRSA_BASE + uri.lstrip("/")
        band = str(row["energy_bandpassname"])
        if url in seen or not band.startswith("SPHEREx-D"):
            continue
        seen.add(url)
        mjd = float(row["time_bounds_lower"])
        frames.append({"id": _key(url), "url": url, "mjd": mjd,
                       "date": Time(mjd, format="mjd").iso[:19],
                       "det": band.replace("SPHEREx-", "")})

    # эпохи: SPHEREx снимает точку пачкой раз в ~полгода
    epoch, prev = 0, None
    for f in frames:
        if prev is not None and f["mjd"] - prev > EPOCH_GAP_DAYS:
            epoch += 1
        f["epoch"], prev = epoch, f["mjd"]

    path.write_text(json.dumps(frames))
    return frames


def _frame_by_id(ra, dec, frame_id) -> dict:
    for f in search_frames(ra, dec):
        if f["id"] == frame_id:
            return f
    raise HTTPException(404, "кадр не найден для этой точки")


# ------------------------------------------------------- cutouts & reproject --
def fetch_cutout(url: str, ra: float, dec: float, fov: float) -> Path:
    """Кутаут MEF из IRSA, кэш навсегда (кадр с данным URL не меняется)."""
    path = CACHE / "fits" / f"{_key(url, round(ra, 5), round(dec, 5), fov)}.fits"
    if not path.exists():
        tmp = _retry(download_file, f"{url}?center={ra},{dec}d&size={fov}")
        shutil.move(tmp, path)
    return path


def _wavelength_um(hdul, coord) -> float:
    hdr = hdul["IMAGE"].header
    x, y = WCS(hdr).world_to_pixel(coord)
    ww = WCS(hdr, fobj=hdul, key="W")
    ww.sip = None
    lam, _ = ww.all_pix2world(float(x), float(y), 0)
    unit = ww.wcs.cunit[0]
    unit = u.um if unit == u.dimensionless_unscaled else u.Unit(unit)
    return float((float(lam) * unit).to(u.um).value)


def read_frame(path: Path, coord: SkyCoord):
    """IMAGE - ZODI; NaN и пиксели с BAD_BITS заполняются медианой кадра."""
    with fits.open(path) as hdul:
        img = hdul["IMAGE"].data.astype(float)
        if "ZODI" in hdul:
            img = img - hdul["ZODI"].data
        bad = ~np.isfinite(img)
        nflag = 0
        if "FLAGS" in hdul:
            flags = hdul["FLAGS"].data.astype(np.int64)
            nflag = int((flags != 0).sum())
            if BAD_BITS:
                bad |= (flags & BAD_BITS) != 0
        good = ~bad
        img[bad] = float(np.median(img[good])) if good.any() else 0.0
        wcs = WCS(hdul["IMAGE"].header)
        try:
            lam = _wavelength_um(hdul, coord)
        except Exception:                                         # noqa: BLE001
            lam = float("nan")
        version = str(hdul[0].header.get("VERSION", ""))
    return img, wcs, lam, version, nflag


@lru_cache(maxsize=1024)
def _load_image(path_str: str):
    """Кадр в памяти (float32 + WCS): повторные клики по спектру не читают диск."""
    with fits.open(path_str) as hdul:
        img = hdul["IMAGE"].data.astype(np.float32)
        if "ZODI" in hdul:
            img = img - hdul["ZODI"].data.astype(np.float32)
        wcs = WCS(hdul["IMAGE"].header)
    return img, wcs


def target_grid(ra, dec, fov):
    """Общая сетка для всех кадров: TAN, север вверх, восток влево."""
    n = max(8, int(math.ceil(fov / PIX_DEG)))
    w = WCS(naxis=2)
    w.wcs.ctype = ["RA---TAN", "DEC--TAN"]
    w.wcs.crval = [ra, dec]
    w.wcs.crpix = [(n + 1) / 2, (n + 1) / 2]
    w.wcs.cdelt = [-PIX_DEG, PIX_DEG]
    return w, (n, n)


def _npy_path(frame_id, ra, dec, fov) -> Path:
    return CACHE / "npy" / f"{_key(frame_id, round(ra, 5), round(dec, 5), fov, CACHE_VER)}.npy"


def process_frame(f: dict, ra, dec, fov) -> dict:
    """Скачать, перепроецировать, сохранить .npy. Возвращает метаданные кадра."""
    npy = _npy_path(f["id"], ra, dec, fov)
    meta_p = npy.with_suffix(".json")
    if npy.exists() and meta_p.exists():
        return json.loads(meta_p.read_text())
    coord = SkyCoord(ra, dec, unit="deg")
    img, wcs, lam, version, nflag = read_frame(fetch_cutout(f["url"], ra, dec, fov), coord)
    out_wcs, shape = target_grid(ra, dec, fov)
    arr, foot = reproject_interp((img, wcs), out_wcs, shape_out=shape)
    arr[foot <= 0] = np.nan                       # вне кадра (край детектора)
    np.save(npy, arr.astype(np.float32))
    meta = {**{k: f[k] for k in ("id", "date", "mjd", "det", "epoch")},
            "lam_um": lam, "version": version, "flagged_px": nflag,
            "coverage": float((foot > 0).mean())}
    meta_p.write_text(json.dumps(meta))
    return meta


def load_npy(frame_id, ra, dec, fov) -> np.ndarray:
    npy = _npy_path(frame_id, ra, dec, fov)
    if not npy.exists():
        raise HTTPException(409, "сначала вызовите /api/frames для этой точки")
    return np.load(npy)


def _robust(arr):
    """Нормировка кадра: фон -> 0, яркие -> ~1 (чтобы складывать разные λ)."""
    med = np.nanmedian(arr)
    top = np.nanpercentile(arr, 99)
    return (arr - med) / (top - med if top > med else 1.0)


def _png_bytes(arr, vmin, vmax, stretch=0.3, cmap="gray") -> bytes:
    norm = ImageNormalize(vmin=vmin, vmax=vmax, stretch=AsinhStretch(a=stretch), clip=True)
    img = np.ma.masked_invalid(norm(np.nan_to_num(arr, nan=vmin))).filled(0)
    buf = io.BytesIO()
    plt.imsave(buf, img, cmap=cmap, vmin=0, vmax=1, origin="lower", format="png")
    return buf.getvalue()


def _png_response(key: str, make) -> Response:
    """PNG с дисковым кэшем: картинка рендерится один раз, дальше отдаётся файлом."""
    path = CACHE / "png" / f"{key}.png"
    if path.exists():
        data = path.read_bytes()
    else:
        data = make()
        path.write_bytes(data)
    return Response(data, media_type="image/png",
                    headers={"Cache-Control": "public, max-age=604800, immutable"})


# ---------------------------------------------------------------- endpoints --
@app.get("/api/resolve")
def resolve(name: str):
    """Имя объекта или строка координат -> RA/Dec в градусах."""
    c = None
    if any(ch.isdigit() for ch in name) and any(ch in name for ch in "hd:°"):
        try:                                       # 08h55m10.8s -07d14m42s / 08:55:10 -07:14:42
            c = SkyCoord(name, unit=(u.hourangle, u.deg))
        except Exception:                                         # noqa: BLE001
            c = None
    if c is None:
        try:
            c = SkyCoord.from_name(name)           # имя объекта через SIMBAD/Sesame
        except Exception as exc:                                  # noqa: BLE001
            raise HTTPException(404, f"объект не найден: {exc}")
    return {"name": name, "ra": c.ra.deg, "dec": c.dec.deg}


@app.get("/api/search")
def api_search(ra: float, dec: float):
    """Список кадров и эпох (быстро, без скачивания картинок)."""
    _check(ra, dec)
    frames = search_frames(ra, dec)
    return {"ra": ra, "dec": dec, "n_frames": len(frames),
            "epochs": sorted({f["epoch"] for f in frames}),
            "frames": [{k: v for k, v in f.items() if k != "url"} for f in frames]}


@app.get("/api/frames")
def api_frames(ra: float, dec: float, fov: float = 0.1,
               det: str = Query("all", pattern="^(all|D[1-6])$"),
               epoch: int | None = None, min_coverage: float = 0.5):
    """Готовит кадры для плеера: скачивание + перепроекция + общая шкала яркости.
    epoch=N — только одна эпоха: сайт грузит эпохи по очереди и показывает первую сразу."""
    _check(ra, dec, fov)
    frames = [f for f in search_frames(ra, dec)
              if (det == "all" or f["det"] == det) and (epoch is None or f["epoch"] == epoch)]
    frames = frames[:MAX_FRAMES]
    with ThreadPoolExecutor(WORKERS) as pool:
        results = list(pool.map(lambda f: _safe(process_frame, f, ra, dec, fov), frames))
    errors = [r["error"] for r in results if "error" in r]
    done = [r for r in results if "error" not in r]
    ok = [m for m in done if m["coverage"] >= min_coverage]     # без обрезков у края
    ok.sort(key=lambda m: m["mjd"])

    # общая шкала яркости по каждому детектору -> кадры не «мигают» от автоконтраста
    scale = {}
    for d in sorted({m["det"] for m in ok}):
        stack = np.concatenate([load_npy(m["id"], ra, dec, fov).ravel()
                                for m in ok if m["det"] == d])
        stack = stack[np.isfinite(stack)]
        if stack.size:
            scale[d] = [float(np.percentile(stack, 1)), float(np.percentile(stack, 99.5))]
    for m in ok:
        m["png"] = f"/api/frame/{m['id']}.png?ra={ra}&dec={dec}&fov={fov}"
    return {"ra": ra, "dec": dec, "fov": fov, "det": det,
            "data_as_of": time.strftime("%Y-%m-%d"),
            "n_requested": len(frames), "n_ok": len(ok),
            "n_failed": len(errors), "n_low_coverage": len(done) - len(ok),
            "errors": sorted(set(errors))[:5], "scale": scale, "frames": ok}


def _safe(fn, *args):
    try:
        return fn(*args)
    except Exception as exc:                                      # noqa: BLE001
        msg = f"{type(exc).__name__}: {exc}"
        print(f"frame failed: {msg}")
        return {"error": msg[:300]}


@app.get("/api/frame/{frame_id}.png")
def api_frame_png(frame_id: str, ra: float, dec: float, fov: float = 0.1,
                  vmin: float | None = None, vmax: float | None = None,
                  stretch: float = 0.3, cmap: str = "gray"):
    key = _key("frame", frame_id, round(ra, 5), round(dec, 5), fov, vmin, vmax,
               stretch, cmap, CACHE_VER)

    def make():
        arr = load_npy(frame_id, ra, dec, fov)
        lo, hi = (vmin, vmax) if vmin is not None and vmax is not None \
            else np.nanpercentile(arr, [1, 99.5])
        return _png_bytes(arr, lo, hi, stretch, cmap)
    return _png_response(key, make)


def _coadd_paths(ra, dec, fov, det, epoch) -> tuple:
    """Готовые (.npy) кадры эпохи; кортеж путей = ключ кэша (новые кадры -> новый ключ)."""
    paths = [_npy_path(f["id"], ra, dec, fov) for f in search_frames(ra, dec)
             if f["epoch"] == epoch and (det == "all" or f["det"] == det)]
    paths = tuple(str(p) for p in paths if p.exists())
    if not paths:
        raise HTTPException(404, "нет обработанных кадров для этой эпохи/детектора")
    return paths


@lru_cache(maxsize=128)
def _coadd_from(paths: tuple) -> np.ndarray:
    return np.nanmedian(np.stack([_robust(np.load(p)) for p in paths]), axis=0)


def _coadd(ra, dec, fov, det, epoch) -> np.ndarray:
    return _coadd_from(_coadd_paths(ra, dec, fov, det, epoch))


@app.get("/api/coadd.png")
def api_coadd(ra: float, dec: float, fov: float = 0.1, epoch: int = 0,
              det: str = Query("all", pattern="^(all|D[1-6])$"),
              stretch: float = 0.3, cmap: str = "gray"):
    """Медиана всех кадров эпохи (по детектору) -> выше S/N."""
    paths = _coadd_paths(ra, dec, fov, det, epoch)
    key = _key("coadd", paths, stretch, cmap)
    return _png_response(key, lambda: _png_bytes(_coadd_from(paths), -0.2, 1.5, stretch, cmap))


@app.get("/api/diff.png")
def api_diff(ra: float, dec: float, fov: float = 0.1, a: int = 0, b: int = 1,
             det: str = Query("all", pattern="^(all|D[1-6])$")):
    """Эпоха b минус эпоха a: неподвижное исчезает, движущееся = пара тёмная/светлая."""
    pa, pb = _coadd_paths(ra, dec, fov, det, a), _coadd_paths(ra, dec, fov, det, b)

    def make():
        d = _coadd_from(pb) - _coadd_from(pa)
        lim = float(np.nanpercentile(np.abs(d), 99.5)) or 1.0
        return _png_bytes(d, -lim, lim, stretch=1.0, cmap="gray")
    return _png_response(_key("diff", pa, pb), make)


@app.get("/api/spectrum")
def api_spectrum(ra: float, dec: float, fov: float = 0.1,
                 x_ra: float | None = None, x_dec: float | None = None, r_px: float = 2.0):
    """Яркость точки (x_ra, x_dec; по умолчанию центр) во всех кадрах -> спектр."""
    _check(ra, dec, fov)
    pt = SkyCoord(x_ra if x_ra is not None else ra, x_dec if x_dec is not None else dec,
                  unit="deg")
    out = []
    win = int(math.ceil(3.5 * r_px)) + 1
    for f in search_frames(ra, dec):
        path = CACHE / "fits" / f"{_key(f['url'], round(ra, 5), round(dec, 5), fov)}.fits"
        meta_p = _npy_path(f["id"], ra, dec, fov).with_suffix(".json")
        if not path.exists() or not meta_p.exists():
            continue                       # спектр строим по уже обработанным кадрам
        try:
            lam = json.loads(meta_p.read_text())["lam_um"]   # λ уже посчитана при обработке
            img, wcs = _load_image(str(path))
            x, y = (float(v) for v in wcs.world_to_pixel(pt))
            x0, y0 = int(round(x)), int(round(y))
            ys, xs = slice(max(0, y0 - win), y0 + win + 1), slice(max(0, x0 - win), x0 + win + 1)
            cut = img[ys, xs]
            if cut.size == 0:
                continue                   # точка вне этого кадра
            yy, xx = np.mgrid[ys, xs]
            rr = np.hypot(xx - x, yy - y)
            ap = cut[rr <= r_px]
            bg = cut[(rr > 2 * r_px) & (rr <= 3.5 * r_px)]
            if np.isfinite(ap).sum() and np.isfinite(bg).sum() and np.isfinite(lam):
                out.append({"id": f["id"], "lam_um": lam,
                            "flux": float(np.nanmean(ap) - np.nanmedian(bg)),
                            "date": f["date"], "det": f["det"], "epoch": f["epoch"]})
        except Exception:                                         # noqa: BLE001
            continue
    out.sort(key=lambda p: p["lam_um"])
    return {"unit": "MJy/sr (средн. в апертуре минус фон)", "points": out}


@app.get("/api/gaia")
def api_gaia(ra: float, dec: float, fov: float = 0.1, date: str | None = None):
    """Звёзды Gaia в поле, позиции перенесены с 2016.0 на дату снимка."""
    _check(ra, dec, fov)
    when = Time(date) if date else Time(2016.0, format="jyear")
    cache_p = CACHE / "gaia" / f"{_key(GAIA_TABLE, round(ra, 4), round(dec, 4), fov, when.jyear.round(2))}.json"
    if cache_p.exists() and time.time() - cache_p.stat().st_mtime < GAIA_TTL_S:
        return json.loads(cache_p.read_text())
    from astroquery.gaia import Gaia
    radius = fov / 2 * math.sqrt(2)
    adql = f"""
        SELECT TOP 3000 source_id AS sid, ra, dec, pmra, pmdec, phot_g_mean_mag AS g
        FROM {GAIA_TABLE}
        WHERE 1 = CONTAINS(POINT('ICRS', ra, dec), CIRCLE('ICRS', {ra}, {dec}, {radius}))
          AND pmra IS NOT NULL
    """
    try:
        t = _retry(lambda: Gaia.launch_job_async(adql).get_results())
    except Exception as exc:                                      # noqa: BLE001
        raise HTTPException(502, f"Gaia Archive недоступен: {type(exc).__name__}: {exc}")
    t.rename_columns(t.colnames, [c.lower() for c in t.colnames])   # регистр зависит от версии

    def col(name):
        return np.ma.filled(np.ma.asarray(t[name], dtype=float), np.nan)

    dt_yr = (when - Time(2016.0, format="jyear")).to_value(u.yr)
    ra0, dec0, pmra, pmdec, g = col("ra"), col("dec"), col("pmra"), col("pmdec"), col("g")
    # линейный перенос по собственному движению (pmra уже содержит cos(dec)), мас/год -> град
    dec1 = dec0 + pmdec * dt_yr / 3.6e6
    ra1 = (ra0 + pmra * dt_yr / 3.6e6 / np.cos(np.radians(dec0))) % 360
    sids = np.ma.filled(np.ma.asarray(t["sid"]), 0)
    stars = [{"source_id": int(s), "ra": float(a), "dec": float(d), "pmra": float(pa),
              "pmdec": float(pd), "g": float(gg) if np.isfinite(gg) else None}
             for s, a, d, pa, pd, gg in zip(sids, ra1, dec1, pmra, pmdec, g)
             if np.isfinite(a) and np.isfinite(d)]
    res = {"catalog": GAIA_TABLE, "epoch": when.iso[:10], "epoch_jyear": float(when.jyear),
           "n": len(stars), "stars": stars}
    cache_p.write_text(json.dumps(res))
    return res


@app.get("/api/health")
def health():
    return {"ok": True, "gaia_table": GAIA_TABLE, "search_ttl_h": SEARCH_TTL_S / 3600}


# --------------------------------------------------------------- static site --
# Сайт (static/index.html, style.css, app.js) отдаётся тем же сервером:
# http://127.0.0.1:5050/  -> сайт,  /api/... -> данные,  /docs -> документация API.
# Монтируется ПОСЛЕДНИМ, чтобы не перекрывать маршруты /api.
from fastapi.staticfiles import StaticFiles                       # noqa: E402

_STATIC = Path(__file__).parent / "static"
if _STATIC.is_dir():
    app.mount("/", StaticFiles(directory=_STATIC, html=True), name="site")

/* SPHEREx Sky Motion Viewer — frontend logic.
 * Talks to the FastAPI backend (api.py). When the page is opened as a local file,
 * it calls the API at http://127.0.0.1:5050; when served by api.py, it uses the same origin.
 */
"use strict";

const API = location.protocol === "file:" ? "http://127.0.0.1:5050" : "";
const PIX_DEG = 6.15 / 3600;      // must match api.py
const PM_YEARS = 10;              // Gaia arrow length = 10 years of motion
const EPOCH_COLORS = ["#5CC8E8", "#F5B342", "#F2867F", "#A98BFA", "#7BD88F"];

const $ = (id) => document.getElementById(id);
const state = {
  ra: null, dec: null, fov: 0.1, det: "D2", view: "frames", name: "",
  frames: [], scale: {}, epochs: [], items: [], idx: 0,
  playing: false, timer: null, gaiaBase: null, click: null, asof: "", token: 0,
};

const jyear = (mjd) => 2000 + (mjd - 51544.5) / 365.25;   // MJD -> decimal year

// ------------------------------------------------------------------ helpers --
async function getJSON(path) {
  const r = await fetch(API + path);
  let body = null;
  try { body = await r.json(); } catch (_) { /* not JSON */ }
  if (!r.ok) throw new Error((body && body.detail) || `HTTP ${r.status}`);
  return body;
}

function setStatus(text, isError = false) {
  const el = $("status");
  el.textContent = text;
  el.classList.toggle("error", isError);
}

function qs(obj) {
  return Object.entries(obj)
    .filter(([, v]) => v !== null && v !== undefined && v !== "")
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
}

function gridFov() {                       // real size of the backend grid
  const n = Math.max(8, Math.ceil(state.fov / PIX_DEG));
  return n * PIX_DEG;
}

// sky (deg) -> stage fraction (0..1, y from top). North up, East left.
function skyToFrac(ra, dec) {
  const f = gridFov();
  const dra = ((ra - state.ra + 540) % 360) - 180;
  return {
    x: 0.5 - (dra * Math.cos(state.dec * Math.PI / 180)) / f,
    y: 0.5 - (dec - state.dec) / f,
  };
}

function fracToSky(fx, fy) {
  const f = gridFov();
  const ra = state.ra + ((0.5 - fx) * f) / Math.cos(state.dec * Math.PI / 180);
  return { ra: (ra + 360) % 360, dec: state.dec + (0.5 - fy) * f };
}

// ---------------------------------------------------------------- URL state --
function readURL() {
  const p = new URLSearchParams(location.search);
  if (p.get("ra") && p.get("dec")) $("target").value = `${p.get("ra")} ${p.get("dec")}`;
  if (p.get("target")) $("target").value = p.get("target");
  if (p.get("fov")) $("fov").value = p.get("fov");
  if (p.get("det")) $("det").value = p.get("det");
  if (p.get("speed")) $("speed").value = p.get("speed");
  if (p.get("stretch")) $("stretch").value = p.get("stretch");
  if (p.get("gaia") === "1") $("gaia-toggle").checked = true;
  if (p.get("view")) state.view = p.get("view");
  setViewButtons();
  return Boolean($("target").value.trim());
}

function writeURL() {
  const params = {
    target: $("target").value.trim(), fov: state.fov, det: state.det, view: state.view,
    speed: $("speed").value, stretch: $("stretch").value,
    gaia: $("gaia-toggle").checked ? 1 : "",
  };
  history.replaceState(null, "", `${location.pathname}?${qs(params)}${location.hash}`);
  $("share-url").value = location.href;
  $("aladin-link").href = `https://aladin.cds.unistra.fr/AladinLite/?${qs({
    target: `${state.ra} ${state.dec}`, fov: state.fov * 2, survey: "CDS/P/allWISE/color",
  })}`;
}

// ------------------------------------------------------------------ loading --
async function resolveTarget(text) {
  const m = text.match(/^\s*(-?\d+(?:\.\d+)?)[\s,]+([+-]?\d+(?:\.\d+)?)\s*$/);
  if (m) return { ra: parseFloat(m[1]), dec: parseFloat(m[2]) };
  return getJSON(`/api/resolve?${qs({ name: text })}`);   // names and 08h55m.. formats
}

async function load() {
  stop();
  const token = ++state.token;            // a newer search cancels this one
  const text = $("target").value.trim();
  state.fov = parseFloat($("fov").value);
  state.det = $("det").value;
  state.click = null;
  state.gaiaBase = null;
  state.frames = []; state.scale = {}; state.epochs = []; state.items = []; state.idx = 0;
  renderTimeline(); show(0); drawSpectrum([]);
  try {
    setStatus("Finding the target…");
    const pos = await resolveTarget(text);
    if (token !== state.token) return;
    state.ra = pos.ra; state.dec = pos.dec;
    $("target-title").textContent = state.name || text;
    writeURL();

    setStatus("Searching the SPHEREx archive (IRSA)…");
    const found = await getJSON(`/api/search?${qs({ ra: state.ra, dec: state.dec })}`);
    if (token !== state.token) return;
    if (!found.n_frames) {
      setStatus("SPHEREx has no images of this point yet. New data arrives every week.", true);
      return;
    }

    // Epoch by epoch: the first epoch is shown as soon as it is ready.
    let requested = 0, lowCov = 0, lastErr = "";
    for (let k = 0; k < found.epochs.length; k++) {
      setStatus(`Loading epoch ${k + 1} of ${found.epochs.length} from IRSA… ` +
        `(${state.frames.length} frames ready; first time can take a minute per epoch)`);
      const res = await getJSON(`/api/frames?${qs({
        ra: state.ra, dec: state.dec, fov: state.fov, det: state.det, epoch: found.epochs[k],
      })}`);
      if (token !== state.token) return;
      requested += res.n_requested;
      lowCov += res.n_low_coverage || 0;
      if (res.errors && res.errors.length) lastErr = res.errors[0];
      state.asof = res.data_as_of;
      if (!res.n_ok) continue;
      for (const [d, sc] of Object.entries(res.scale)) if (!state.scale[d]) state.scale[d] = sc;
      state.frames = state.frames.concat(res.frames).sort((a, b) => a.mjd - b.mjd);
      state.epochs = [...new Set(state.frames.map((f) => f.epoch))].sort((a, b) => a - b);
      const wasPlaying = state.playing;
      buildSequence(state.idx);
      if (wasPlaying) play();
    }

    if (!state.frames.length) {
      const why = lastErr ? ` Server error: ${lastErr}`
        : lowCov ? ` ${lowCov} frame(s) only partly cover this field (target near a detector edge) — try a smaller field.`
        : "";
      setStatus(`No usable frames for detector ${state.det}.${why}`, true);
      return;
    }
    $("m-asof").textContent =
      `IRSA data as of ${state.asof} · ${state.frames.length} of ${requested} frames usable`;
    setStatus(`${state.frames.length} frames ready across ${state.epochs.length} epoch(s). Press Play.`);
    if ($("gaia-toggle").checked) await loadGaia();
  } catch (err) {
    if (token === state.token) setStatus(`Something went wrong: ${err.message}`, true);
  }
}

// ---------------------------------------------------------------- sequences --
function framePng(f) {
  const [vmin, vmax] = state.scale[f.det] || [null, null];
  return `${API}${f.png}&${qs({ vmin, vmax, stretch: $("stretch").value })}`;
}

function epochDate(e) {
  const f = state.frames.find((x) => x.epoch === e);
  return f ? f.date.slice(0, 10) : "";
}

function epochYear(e) {
  const f = state.frames.find((x) => x.epoch === e);
  return f ? jyear(f.mjd) : null;
}

function buildSequence(startIdx = 0) {
  const base = { ra: state.ra, dec: state.dec, fov: state.fov, det: state.det };
  const stretch = $("stretch").value;
  if (state.view === "coadd") {
    state.items = state.epochs.map((e) => ({
      src: `${API}/api/coadd.png?${qs({ ...base, epoch: e, stretch })}`,
      label: `E${e + 1}`, epoch: e, date: epochDate(e), det: state.det, kind: "coadd",
      t: epochYear(e),
    }));
  } else if (state.view === "diff") {
    state.items = [];
    for (let i = 1; i < state.epochs.length; i++) {
      const a = state.epochs[i - 1], b = state.epochs[i];
      state.items.push({
        src: `${API}/api/diff.png?${qs({ ...base, a, b })}`,
        label: `E${b + 1}−E${a + 1}`, epoch: b, date: `${epochDate(a)} → ${epochDate(b)}`,
        det: state.det, kind: "diff", t: epochYear(b),
      });
    }
    if (!state.items.length) {
      setStatus("Epoch difference needs at least two epochs. This point has only one so far.", true);
    }
  } else {
    state.items = state.frames.map((f, i) => ({
      src: framePng(f), label: String(i + 1), epoch: f.epoch, date: f.date, id: f.id,
      t: jyear(f.mjd),
      det: f.det, lam: f.lam_um, ver: f.version, flagged: f.flagged_px, kind: "frame",
    }));
  }
  state.items.forEach((it) => { const im = new Image(); im.src = it.src; });  // preload
  renderTimeline();
  show(startIdx);
}

function renderTimeline() {
  const tl = $("timeline");
  tl.innerHTML = "";
  let lastEpoch = null;
  state.items.forEach((it, i) => {
    if (it.kind === "frame" && it.epoch !== lastEpoch) {
      const sep = document.createElement("span");
      sep.className = "sep";
      sep.textContent = `Epoch ${it.epoch + 1} · ${epochDate(it.epoch)}`;
      tl.appendChild(sep);
      lastEpoch = it.epoch;
    }
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = it.label;
    b.setAttribute("aria-label", `Show ${it.kind} ${it.label}`);
    b.addEventListener("click", () => { stop(); show(i); });
    tl.appendChild(b);
  });
}

function show(i) {
  if (!state.items.length) {
    $("frame-img").hidden = true; $("stage-empty").hidden = false; $("frame-label").hidden = true;
    return;
  }
  state.idx = (i + state.items.length) % state.items.length;
  const it = state.items[state.idx];
  const img = $("frame-img");
  img.src = it.src;
  img.hidden = false;
  $("stage-empty").hidden = true;

  const lam = Number.isFinite(it.lam) ? ` · λ ${it.lam.toFixed(3)} µm` : "";
  const what = it.kind === "frame" ? `Frame ${state.idx + 1} of ${state.items.length}`
    : it.kind === "coadd" ? `Co-add, epoch ${it.epoch + 1}` : `Difference ${it.label}`;
  $("frame-label").textContent = `${what} · ${it.date.slice(0, 19)}${lam}`;
  $("frame-label").hidden = false;

  $("m-date").textContent = it.date.slice(0, 19) || "—";
  $("m-epoch").textContent = it.epoch + 1;
  $("m-det").textContent = it.det;
  $("m-lam").textContent = Number.isFinite(it.lam) ? `${it.lam.toFixed(3)} µm` : "—";
  $("m-ver").textContent = it.ver || "—";
  $("m-flag").textContent = it.flagged !== undefined ? it.flagged : "—";

  [...$("timeline").querySelectorAll("button")].forEach((b, k) =>
    b.classList.toggle("on", k === state.idx));
  drawOverlay();
}

// ------------------------------------------------------------------ playback --
function play() {
  if (state.items.length < 2) return;
  state.playing = true;
  $("play").textContent = "Pause";
  clearInterval(state.timer);
  state.timer = setInterval(() => show(state.idx + 1), parseInt($("speed").value, 10));
}

function stop() {
  state.playing = false;
  $("play").textContent = "Play";
  clearInterval(state.timer);
}

// -------------------------------------------------------------------- Gaia --
async function loadGaia() {
  if (state.ra === null) return;
  if (!state.gaiaBase) {
    try {   // one request: positions at 2016.0 + proper motions; moved to each frame date here
      state.gaiaBase = await getJSON(`/api/gaia?${qs({ ra: state.ra, dec: state.dec, fov: state.fov })}`);
    } catch (err) {
      setStatus(`Gaia overlay unavailable: ${err.message}`, true);
      return;
    }
  }
  drawOverlay();
}

function gaiaAt(year) {
  const base = state.gaiaBase;
  if (!base || year === null || year === undefined) return [];
  const dt = year - base.epoch_jyear;
  return base.stars.map((s) => ({
    ...s,
    ra: s.ra + (s.pmra * dt / 3.6e6) / Math.cos(s.dec * Math.PI / 180),
    dec: s.dec + s.pmdec * dt / 3.6e6,
  }));
}

function drawOverlay() {
  const svg = $("overlay");
  svg.setAttribute("viewBox", "0 0 1000 1000");
  let html = "";
  const it = state.items[state.idx];
  const stars = it && $("gaia-toggle").checked ? gaiaAt(it.t) : null;
  if (stars && stars.length) {
    const f = gridFov();
    for (const s of stars) {
      const p = skyToFrac(s.ra, s.dec);
      if (p.x < 0 || p.x > 1 || p.y < 0 || p.y > 1) continue;
      const x = p.x * 1000, y = p.y * 1000;
      const dx = -(s.pmra * PM_YEARS / 3.6e6) / f * 1000;   // East is left
      const dy = -(s.pmdec * PM_YEARS / 3.6e6) / f * 1000;  // North is up
      const r = s.g === null ? 6 : Math.max(4, 14 - s.g / 2);
      html += `<circle cx="${x}" cy="${y}" r="${r}" fill="none" stroke="#5CC8E8" stroke-width="2" opacity="0.8"/>`;
      if (Math.hypot(dx, dy) > 4) {
        html += `<line x1="${x}" y1="${y}" x2="${x + dx}" y2="${y + dy}" stroke="#5CC8E8" stroke-width="2"/>`;
      }
    }
  }
  if (state.click) {
    const p = skyToFrac(state.click.ra, state.click.dec);
    const x = p.x * 1000, y = p.y * 1000;
    html += `<circle cx="${x}" cy="${y}" r="18" fill="none" stroke="#F5B342" stroke-width="3"/>` +
      `<line x1="${x - 30}" y1="${y}" x2="${x - 20}" y2="${y}" stroke="#F5B342" stroke-width="3"/>` +
      `<line x1="${x + 20}" y1="${y}" x2="${x + 30}" y2="${y}" stroke="#F5B342" stroke-width="3"/>`;
  }
  svg.innerHTML = html;
}

// ----------------------------------------------------------------- spectrum --
async function loadSpectrum(ra, dec) {
  $("spec-note").textContent = "Measuring this point in every frame…";
  try {
    const res = await getJSON(`/api/spectrum?${qs({
      ra: state.ra, dec: state.dec, fov: state.fov, x_ra: ra.toFixed(6), x_dec: dec.toFixed(6),
    })}`);
    drawSpectrum(res.points);
    $("spec-note").textContent =
      `RA ${ra.toFixed(4)}°, Dec ${dec.toFixed(4)}° · ${res.points.length} measurements. ` +
      "Click a dot to jump to that frame. Tip: choose detector All (D1–D6) for the full 0.75–5 µm spectrum.";
  } catch (err) {
    $("spec-note").textContent = `Spectrum unavailable: ${err.message}`;
  }
}

function niceTicks(lo, hi, count = 5) {
  const raw = (hi - lo) / count;
  const mag = 10 ** Math.floor(Math.log10(raw));
  const step = [1, 2, 2.5, 5, 10].map((m) => m * mag).find((v) => v >= raw) || raw;
  const out = [];
  for (let v = Math.ceil(lo / step) * step; v <= hi + 1e-9; v += step) out.push(+v.toFixed(10));
  return out;
}

function drawSpectrum(points) {
  const svg = $("spectrum");
  const legend = $("spec-legend");
  const W = 960, H = 360, L = 78, R = 24, T = 20, B = 56;
  const pts = (points || []).filter((p) => Number.isFinite(p.lam_um) && Number.isFinite(p.flux));
  if (!pts.length) {
    legend.innerHTML = "";
    svg.innerHTML = `<text x="${W / 2}" y="${H / 2}" fill="#9AA3B8" font-size="18" text-anchor="middle">` +
      `${points ? "No measurements yet — click a point in the image" : ""}</text>`;
    return;
  }
  const lams = pts.map((p) => p.lam_um), fl = pts.map((p) => p.flux);
  let xmin = Math.max(0.7, Math.min(...lams) - 0.1), xmax = Math.min(5.1, Math.max(...lams) + 0.1);
  let ymin = Math.min(...fl), ymax = Math.max(...fl);
  if (ymax === ymin) { ymax += 1; ymin -= 1; }
  const pad = (ymax - ymin) * 0.08; ymin -= pad; ymax += pad;
  const X = (v) => L + ((v - xmin) / (xmax - xmin)) * (W - L - R);
  const Y = (v) => H - B - ((v - ymin) / (ymax - ymin)) * (H - T - B);

  let s = "";
  for (const t of niceTicks(ymin, ymax, 5)) {           // horizontal grid + y labels
    s += `<line x1="${L}" y1="${Y(t)}" x2="${W - R}" y2="${Y(t)}" stroke="#1E2740"/>` +
      `<text x="${L - 10}" y="${Y(t) + 5}" fill="#9AA3B8" font-size="14" text-anchor="end">${t}</text>`;
  }
  if (ymin < 0 && ymax > 0) {
    s += `<line x1="${L}" y1="${Y(0)}" x2="${W - R}" y2="${Y(0)}" stroke="#2C3755" stroke-dasharray="4 4"/>`;
  }
  for (const t of niceTicks(xmin, xmax, 8)) {           // x ticks
    s += `<line x1="${X(t)}" y1="${H - B}" x2="${X(t)}" y2="${H - B + 6}" stroke="#2C3755"/>` +
      `<text x="${X(t)}" y="${H - B + 24}" fill="#9AA3B8" font-size="14" text-anchor="middle">${t}</text>`;
  }
  s += `<line x1="${L}" y1="${T}" x2="${L}" y2="${H - B}" stroke="#2C3755"/>` +
    `<line x1="${L}" y1="${H - B}" x2="${W - R}" y2="${H - B}" stroke="#2C3755"/>` +
    `<text x="${(L + W - R) / 2}" y="${H - 8}" fill="#C9CFDD" font-size="15" text-anchor="middle">Wavelength, µm</text>` +
    `<text x="18" y="${(T + H - B) / 2}" fill="#C9CFDD" font-size="15" text-anchor="middle" transform="rotate(-90 18 ${(T + H - B) / 2})">Brightness, MJy/sr</text>`;

  const epochs = [...new Set(pts.map((p) => p.epoch))].sort((a, b) => a - b);
  for (const e of epochs) {                               // a faint line per epoch, then the dots
    const c = EPOCH_COLORS[e % EPOCH_COLORS.length];
    const line = pts.filter((p) => p.epoch === e).sort((a, b) => a.lam_um - b.lam_um)
      .map((p) => `${X(p.lam_um).toFixed(1)},${Y(p.flux).toFixed(1)}`).join(" ");
    s += `<polyline points="${line}" fill="none" stroke="${c}" stroke-width="1.5" opacity="0.35"/>`;
  }
  for (const p of pts) {
    const c = EPOCH_COLORS[p.epoch % EPOCH_COLORS.length];
    s += `<circle class="pt" data-id="${p.id || ""}" cx="${X(p.lam_um)}" cy="${Y(p.flux)}" r="5" fill="${c}">` +
      `<title>${p.lam_um.toFixed(3)} µm · ${p.flux.toPrecision(3)} MJy/sr · ${p.date.slice(0, 10)} · ${p.det}</title></circle>`;
  }
  svg.innerHTML = s;
  legend.innerHTML = epochs.map((e) =>
    `<span><i style="background:${EPOCH_COLORS[e % EPOCH_COLORS.length]}"></i>Epoch ${e + 1} · ${epochDate(e)}</span>`).join("");
}

// ------------------------------------------------------------------- events --
function setViewButtons() {
  document.querySelectorAll(".segmented button").forEach((b) =>
    b.classList.toggle("on", b.dataset.view === state.view));
}

$("search-form").addEventListener("submit", (e) => {
  e.preventDefault();
  state.name = "";
  load();
});

document.querySelectorAll(".segmented button").forEach((b) =>
  b.addEventListener("click", () => {
    stop();
    state.view = b.dataset.view;
    setViewButtons();
    if (state.frames.length) { buildSequence(); writeURL(); }
  }));

$("play").addEventListener("click", () => (state.playing ? stop() : play()));
$("prev").addEventListener("click", () => { stop(); show(state.idx - 1); });
$("next").addEventListener("click", () => { stop(); show(state.idx + 1); });
$("speed").addEventListener("input", () => { if (state.playing) play(); });
$("speed").addEventListener("change", () => state.ra !== null && writeURL());
$("stretch").addEventListener("change", () => {
  if (state.frames.length) { const i = state.idx; buildSequence(); show(i); writeURL(); }
});
$("gaia-toggle").addEventListener("change", async () => {
  if ($("gaia-toggle").checked) await loadGaia(); else drawOverlay();
  if (state.ra !== null) writeURL();
});

$("stage").addEventListener("click", (e) => {
  if (state.ra === null || !state.items.length) return;
  const r = e.currentTarget.getBoundingClientRect();
  const sky = fracToSky((e.clientX - r.left) / r.width, (e.clientY - r.top) / r.height);
  state.click = sky;
  drawOverlay();
  loadSpectrum(sky.ra, sky.dec);
});

$("spectrum").addEventListener("click", (e) => {
  const id = e.target.dataset && e.target.dataset.id;
  if (!id) return;
  if (state.view !== "frames") { state.view = "frames"; setViewButtons(); buildSequence(); }
  const i = state.items.findIndex((it) => it.id === id);
  if (i >= 0) { stop(); show(i); $("stage").scrollIntoView({ behavior: "smooth", block: "center" }); }
});

$("copy").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText($("share-url").value); $("copy").textContent = "Copied"; }
  catch (_) { $("share-url").select(); }
  setTimeout(() => ($("copy").textContent = "Copy"), 1500);
});

document.querySelectorAll("[data-target]").forEach((b) =>
  b.addEventListener("click", () => {
    $("target").value = b.dataset.target;
    if (b.dataset.det) $("det").value = b.dataset.det;
    state.name = b.dataset.name || "";
    document.getElementById("viewer").scrollIntoView();
    load();
  }));

document.addEventListener("keydown", (e) => {
  if (["INPUT", "SELECT", "TEXTAREA", "BUTTON"].includes(document.activeElement.tagName)) return;
  if (e.key === "ArrowRight") { stop(); show(state.idx + 1); }
  else if (e.key === "ArrowLeft") { stop(); show(state.idx - 1); }
  else if (e.key === " ") { e.preventDefault(); state.playing ? stop() : play(); }
});

// nav highlight
const navLinks = [...document.querySelectorAll(".nav a")];
const observer = new IntersectionObserver((entries) => {
  entries.forEach((en) => {
    if (en.isIntersecting) {
      navLinks.forEach((a) => a.classList.toggle("active", a.getAttribute("href") === `#${en.target.id}`));
    }
  });
}, { rootMargin: "-40% 0px -55% 0px" });
document.querySelectorAll("main > section").forEach((s) => observer.observe(s));

// start
if (readURL()) load();
